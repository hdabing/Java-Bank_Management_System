import java.awt.font.*;
import java.awt.*;

public class Start{
	public static void main(String[] args) throws Exception{
		
		javax.swing.UIManager.setLookAndFeel("com.jtattoo.plaf.hifi.HiFiLookAndFeel");
		MyFrame9 my  = new MyFrame9();
		
	}
}